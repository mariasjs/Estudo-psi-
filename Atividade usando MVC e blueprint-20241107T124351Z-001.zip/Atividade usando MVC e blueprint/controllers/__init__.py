
all = [
    'books',
    'users',
    'emprestimo'
]