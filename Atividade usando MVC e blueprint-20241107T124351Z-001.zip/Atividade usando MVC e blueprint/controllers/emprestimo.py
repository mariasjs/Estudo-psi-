from flask import render_template, Blueprint, url_for, request, flash, redirect
from models.emprestimo import Emprestimo

bp = Blueprint('emprestimo', __name__, url_prefix='/emprestimo')

#Nos apps.routes utiliza-se o nome da variavel definida anteriormente (bp)
@bp.route('/')
def index():
    return render_template('emprestimo/index.html', emprestimo = Emprestimo.all())#Retorna a lista de empréstimos realizados 

@bp.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        titulo_liv = request.form['titulo_liv']
        data_emp = request.form['data_emp']
        id_user = request.form['id_user']
        id_book = request.form['id_book']
        emprestimo = Emprestimo(titulo_liv,data_emp,id_user,id_book) #Adiciona um novo emprestimo com esses dados fornecidos 
        emprestimo.save() #Salva no banco de dados 
        return redirect(url_for('emprestimo.index'))

    return render_template('emprestimo/register.html')