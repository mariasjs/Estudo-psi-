from flask import Flask
from controllers import users, books, emprestimo

app = Flask(__name__)

app.register_blueprint(users.bp)
app.register_blueprint(books.bp)
app.register_blueprint(emprestimo.bp)

# register_blueprint é essencial para juntar esses módulos em um único arquivo, neste caso (app.py),mantendo um controle eficiente e organizado.
#Caso os modulos não sejam salvos aqui, da erro ao rodar o codigo






