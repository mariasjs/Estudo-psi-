from database import get_connection

class Emprestimo:
    def __init__(self, titulo_liv,data_emp, id_user, id_book):
        self.titulo_liv = titulo_liv
        self.data_emp = data_emp
        self.id_user = id_user
        self.id_book = id_book

    def save(self):
        conn = get_connection()
        conn.execute("INSERT INTO emprestimos(titulo_liv,data_emp, id_user, id_book) values(?,?,?,?)", (self.titulo_liv,self.data_emp, self.id_user, self.id_book))
        conn.commit()
        conn.close()
        return True

    @classmethod
    def all(cls):
        conn = get_connection()
        emprestimos = conn.execute("SELECT * FROM emprestimos").fetchall()
        return emprestimos