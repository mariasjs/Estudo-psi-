
__all__ = [ #Esta lista indica os itens que o módulo tornará disponíveis para serem importados.
    'user',
    'book',
    'emprestimo'
]