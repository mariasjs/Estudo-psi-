class Estudante:
    def __init__(self, nome: str, matricula: int):
        self.nome = nome
        self.matricula = matricula
        
   